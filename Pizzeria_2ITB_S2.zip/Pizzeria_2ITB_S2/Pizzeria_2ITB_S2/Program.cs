﻿using Pizzeria_2ITB_S2;

class Program {
    static void Main(string[] args) {
        Sklad sklad = new Sklad();
        sklad.VypisSuroviny();
    }
}