﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Sklad
    {
        protected List<Suroviny> dostupneSuroviny = new List<Suroviny>();
        Random rnd = new Random();

        public Sklad() {
            VytvorSuroviny();
        }
        void VytvorSuroviny() {
            foreach (var item in Suroviny.ingredience) {
                dostupneSuroviny.Add(new Suroviny(item, rnd.Next(rnd.Next(500, 10000))));
            }
        }
        public void VypisSuroviny() {
            foreach (var item in dostupneSuroviny)
            {
                Console.WriteLine("{0} - {1}g/ml", item.nazev, item.mnozstvi);
            }
        }
    }
}
