﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Auto
    {
        string znacka, druhAuta;
        float spotreba;
        bool kDispozici;
        float najeteKm;

        Random rnd = new Random();
        public static List<Auto> dostupnaAuta = new List<Auto>();
        public Auto(string znacka, string druhAuta, float spotreba)
        {
            this.znacka = znacka;
            this.druhAuta = druhAuta;
            this.spotreba = spotreba;
            kDispozici = true;
            dostupnaAuta.Add(this);
            najeteKm = rnd.Next(2, 12938);
        }
        
    }
}
