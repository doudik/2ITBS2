﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Pizzerie : Sklad
    {
        List<Auto> auta = new List<Auto>();
        List<Pizza> pizzyVPeci = new List<Pizza>();
        
        static int pocetMistVPeci = 5;
        static int volnaMistaVPeci = pocetMistVPeci;
        int pocetTesta = 0;

        IDictionary<string, string> oteviraciDoba = new Dictionary<string, string>();
        void OteviraciDoba() {
            oteviraciDoba.Add("Po", "8:00 - 16:30");
            oteviraciDoba.Add("Út", "8:00 - 16:30");
            oteviraciDoba.Add("St", "8:00 - 16:30");
            oteviraciDoba.Add("Čt", "8:00 - 16:30");
            oteviraciDoba.Add("Pá", "8:00 - 16:30");
        }

        void VyndejPizzu(Pizza pizza)
        {
            if (volnaMistaVPeci != 5)
            {
                pizzyVPeci.Remove(pizza);
                volnaMistaVPeci++;
                Console.WriteLine("Vyndal si z pece pizzu {0}", pizza.druh);
            }
            else {
                Console.WriteLine("Pec je prázdná!");
            }
        }
        void ZandejPizzu(Pizza pizza) {
            if (volnaMistaVPeci == 0)
            {
                pizzyVPeci.Add(pizza);
                volnaMistaVPeci--;
                Console.WriteLine("Vložil si do pece pizzu {0}", pizza.druh);
            }
            else {
                Console.WriteLine("V peci je momentálně plno!");
            }
        }
        int GetIndex(string nazev) {
            for (int i = 0; i < dostupneSuroviny.Count; i++)
            {
                if (dostupneSuroviny[i].nazev == nazev) {
                    return i;
                }
            }
            return -1;
        }
        void VytvorTesto() {
            int needMouka = 400;
            int needVoda = 200;
            int needSul = 25;
            int needDrozdi = 20;
            if (dostupneSuroviny[GetIndex("mouka")].mnozstvi > needMouka &&
                dostupneSuroviny[GetIndex("voda")].mnozstvi > needVoda &&
                dostupneSuroviny[GetIndex("sůl")].mnozstvi > needSul &&
                dostupneSuroviny[GetIndex("droždí")].mnozstvi > needDrozdi)
            {
                Console.WriteLine("Vytvořil si těsto na pizzu!");
                pocetTesta++;
                dostupneSuroviny[GetIndex("mouka")].mnozstvi -= needMouka;
                dostupneSuroviny[GetIndex("voda")].mnozstvi -= needVoda;
                dostupneSuroviny[GetIndex("sůl")].mnozstvi -= needSul;
                dostupneSuroviny[GetIndex("droždí")].mnozstvi -= needDrozdi;
            }
            else {
                Console.WriteLine("Nemáš dostatek surovin! Které si zjisti sám (:");
            }
        }
    }
}
