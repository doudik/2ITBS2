﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Suroviny
    {
        public static List<string> ingredience = new List<string>() {"mouka","voda","droždí","sůl",
        "gouda","eidam","niva","parmazán","raj. protlak","ananas","šunka","salám"};
        public string nazev { get; }
        public int mnozstvi { get; set; }

        public Suroviny(string nazev, int mnozstvi) {
            this.nazev = nazev;
            this.mnozstvi = mnozstvi;
        }
    }
}
