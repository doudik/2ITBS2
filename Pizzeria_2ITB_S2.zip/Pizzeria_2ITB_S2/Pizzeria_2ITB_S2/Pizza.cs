﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Pizza
    {
        public string druh { get; }

        public Pizza(string druh)
        {
            this.druh = druh;
        }
    }
}
