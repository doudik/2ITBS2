﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria_2ITB_S2
{
    internal class Rozvoz
    {
        string cilovaAdresa;
        float celkoveKm;
        DateTime cas;

    }
}
