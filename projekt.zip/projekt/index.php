<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method="post">
        <label for="name">Jméno</label>
        <input type="text" name="name" id="name">
        <input type="submit" value="Přidej záznam">
    </form>
    <br>
</body>
</html>

<?php
writeData();
getData();
function writeData(){
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        require "config.php";
        $name = $_POST["name"];
        $sql = "INSERT INTO users (Name) VALUES ('$name')";
        $conn->query($sql);
        $conn->close();
    }
}
function getData(){
    require "config.php";

    $sql = "SELECT * FROM users";
    $result = $conn->query($sql);
    if($result->num_rows  > 0){
        while($row = $result->fetch_assoc()){
            echo "id: " . $row['id'] . " name: " . $row['Name'] . "<br>";
        }
    }
    $conn->close();

}